﻿namespace Lewtz
{
    partial class FormLewtz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkCombineHoards = new System.Windows.Forms.CheckBox();
            this.btnAddTreasure = new System.Windows.Forms.Button();
            this.GenerateLootButton = new System.Windows.Forms.Button();
            this.btnRemoveTreasure = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.grpPanel1 = new System.Windows.Forms.Panel();
            this.pnlInput9 = new System.Windows.Forms.Panel();
            this.CoinsBox10 = new System.Windows.Forms.ComboBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.ItemsBox10 = new System.Windows.Forms.ComboBox();
            this.NumberToRollBox10 = new System.Windows.Forms.TextBox();
            this.GoodsBox10 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.LevelBox10 = new System.Windows.Forms.ComboBox();
            this.pnlInput8 = new System.Windows.Forms.Panel();
            this.CoinsBox9 = new System.Windows.Forms.ComboBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.ItemsBox9 = new System.Windows.Forms.ComboBox();
            this.NumberToRollBox9 = new System.Windows.Forms.TextBox();
            this.GoodsBox9 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.LevelBox9 = new System.Windows.Forms.ComboBox();
            this.pnlInput7 = new System.Windows.Forms.Panel();
            this.CoinsBox8 = new System.Windows.Forms.ComboBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.ItemsBox8 = new System.Windows.Forms.ComboBox();
            this.NumberToRollBox8 = new System.Windows.Forms.TextBox();
            this.GoodsBox8 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.LevelBox8 = new System.Windows.Forms.ComboBox();
            this.pnlInput0 = new System.Windows.Forms.Panel();
            this.lblItems = new System.Windows.Forms.Label();
            this.GoodsLabel = new System.Windows.Forms.Label();
            this.lblCoins = new System.Windows.Forms.Label();
            this.CheckBox1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.NumberToRollBox1 = new System.Windows.Forms.TextBox();
            this.ItemsBox1 = new System.Windows.Forms.ComboBox();
            this.GoodsBox1 = new System.Windows.Forms.ComboBox();
            this.LevelBox1 = new System.Windows.Forms.ComboBox();
            this.CoinsBox1 = new System.Windows.Forms.ComboBox();
            this.pnlInput1 = new System.Windows.Forms.Panel();
            this.CoinsBox2 = new System.Windows.Forms.ComboBox();
            this.CheckBox2 = new System.Windows.Forms.CheckBox();
            this.ItemsBox2 = new System.Windows.Forms.ComboBox();
            this.NumberToRollBox2 = new System.Windows.Forms.TextBox();
            this.GoodsBox2 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.LevelBox2 = new System.Windows.Forms.ComboBox();
            this.pnlInput5 = new System.Windows.Forms.Panel();
            this.CoinsBox6 = new System.Windows.Forms.ComboBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.ItemsBox6 = new System.Windows.Forms.ComboBox();
            this.NumberToRollBox6 = new System.Windows.Forms.TextBox();
            this.GoodsBox6 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.LevelBox6 = new System.Windows.Forms.ComboBox();
            this.pnlInput6 = new System.Windows.Forms.Panel();
            this.CoinsBox7 = new System.Windows.Forms.ComboBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.ItemsBox7 = new System.Windows.Forms.ComboBox();
            this.NumberToRollBox7 = new System.Windows.Forms.TextBox();
            this.GoodsBox7 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.LevelBox7 = new System.Windows.Forms.ComboBox();
            this.pnlInput4 = new System.Windows.Forms.Panel();
            this.CoinsBox5 = new System.Windows.Forms.ComboBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.ItemsBox5 = new System.Windows.Forms.ComboBox();
            this.NumberToRollBox5 = new System.Windows.Forms.TextBox();
            this.GoodsBox5 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.LevelBox5 = new System.Windows.Forms.ComboBox();
            this.pnlInput2 = new System.Windows.Forms.Panel();
            this.CoinsBox3 = new System.Windows.Forms.ComboBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.ItemsBox3 = new System.Windows.Forms.ComboBox();
            this.NumberToRollBox3 = new System.Windows.Forms.TextBox();
            this.GoodsBox3 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.LevelBox3 = new System.Windows.Forms.ComboBox();
            this.pnlInput3 = new System.Windows.Forms.Panel();
            this.CoinsBox4 = new System.Windows.Forms.ComboBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.ItemsBox4 = new System.Windows.Forms.ComboBox();
            this.NumberToRollBox4 = new System.Windows.Forms.TextBox();
            this.GoodsBox4 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.LevelBox4 = new System.Windows.Forms.ComboBox();
            this.grpRank = new System.Windows.Forms.GroupBox();
            this.chkIncludeAllRank = new System.Windows.Forms.CheckBox();
            this.chkIncludeMajor = new System.Windows.Forms.CheckBox();
            this.chkIncludeMedium = new System.Windows.Forms.CheckBox();
            this.chkIncludeMinor = new System.Windows.Forms.CheckBox();
            this.grpSalvage = new System.Windows.Forms.GroupBox();
            this.grpSpecificArea = new System.Windows.Forms.GroupBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.chkIncludeDesert = new System.Windows.Forms.CheckBox();
            this.chkIbcludeFrostburn = new System.Windows.Forms.CheckBox();
            this.grpIncludeItems = new System.Windows.Forms.GroupBox();
            this.chkIncludeTools = new System.Windows.Forms.CheckBox();
            this.chkIncludeAlchemy = new System.Windows.Forms.CheckBox();
            this.chkIncludeSalvage = new System.Windows.Forms.CheckBox();
            this.chkIncludeAlcohol = new System.Windows.Forms.CheckBox();
            this.chkIncludeAll = new System.Windows.Forms.CheckBox();
            this.chkIncludeArt = new System.Windows.Forms.CheckBox();
            this.chkIncludeGems = new System.Windows.Forms.CheckBox();
            this.chkIncludeArmor = new System.Windows.Forms.CheckBox();
            this.chkIncludeWeapons = new System.Windows.Forms.CheckBox();
            this.grpIncludeMagic = new System.Windows.Forms.GroupBox();
            this.chkIncludeAllMagic = new System.Windows.Forms.CheckBox();
            this.chkIncludeWondrous = new System.Windows.Forms.CheckBox();
            this.chkIncludeRods = new System.Windows.Forms.CheckBox();
            this.chkIncludePotions = new System.Windows.Forms.CheckBox();
            this.chkIncludeStaves = new System.Windows.Forms.CheckBox();
            this.chkIncludeMagic = new System.Windows.Forms.CheckBox();
            this.chkIncludeWands = new System.Windows.Forms.CheckBox();
            this.chkIncludeRings = new System.Windows.Forms.CheckBox();
            this.chkIncludeScrolls = new System.Windows.Forms.CheckBox();
            this.splitText = new System.Windows.Forms.SplitContainer();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lootTableToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.grpPanel1.SuspendLayout();
            this.pnlInput9.SuspendLayout();
            this.pnlInput8.SuspendLayout();
            this.pnlInput7.SuspendLayout();
            this.pnlInput0.SuspendLayout();
            this.pnlInput1.SuspendLayout();
            this.pnlInput5.SuspendLayout();
            this.pnlInput6.SuspendLayout();
            this.pnlInput4.SuspendLayout();
            this.pnlInput2.SuspendLayout();
            this.pnlInput3.SuspendLayout();
            this.grpRank.SuspendLayout();
            this.grpSpecificArea.SuspendLayout();
            this.grpIncludeItems.SuspendLayout();
            this.grpIncludeMagic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitText)).BeginInit();
            this.splitText.Panel1.SuspendLayout();
            this.splitText.Panel2.SuspendLayout();
            this.splitText.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 28);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitText);
            this.splitContainer1.Size = new System.Drawing.Size(1192, 716);
            this.splitContainer1.SplitterDistance = 585;
            this.splitContainer1.TabIndex = 29;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.AutoScroll = true;
            this.splitContainer2.Panel1.Controls.Add(this.panel1);
            this.splitContainer2.Panel1.Controls.Add(this.flowLayoutPanel1);
            this.splitContainer2.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.grpRank);
            this.splitContainer2.Panel2.Controls.Add(this.grpSalvage);
            this.splitContainer2.Panel2.Controls.Add(this.grpSpecificArea);
            this.splitContainer2.Panel2.Controls.Add(this.grpIncludeItems);
            this.splitContainer2.Panel2.Controls.Add(this.grpIncludeMagic);
            this.splitContainer2.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.splitContainer2.Size = new System.Drawing.Size(583, 714);
            this.splitContainer2.SplitterDistance = 417;
            this.splitContainer2.TabIndex = 13;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.chkCombineHoards);
            this.panel1.Controls.Add(this.btnAddTreasure);
            this.panel1.Controls.Add(this.GenerateLootButton);
            this.panel1.Controls.Add(this.btnRemoveTreasure);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 381);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(583, 36);
            this.panel1.TabIndex = 13;
            // 
            // chkCombineHoards
            // 
            this.chkCombineHoards.AutoSize = true;
            this.chkCombineHoards.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCombineHoards.ForeColor = System.Drawing.Color.Black;
            this.chkCombineHoards.Location = new System.Drawing.Point(296, 7);
            this.chkCombineHoards.Name = "chkCombineHoards";
            this.chkCombineHoards.Size = new System.Drawing.Size(162, 22);
            this.chkCombineHoards.TabIndex = 36;
            this.chkCombineHoards.Text = "Combine All Hoards";
            this.chkCombineHoards.UseVisualStyleBackColor = true;
            // 
            // btnAddTreasure
            // 
            this.btnAddTreasure.Location = new System.Drawing.Point(3, 3);
            this.btnAddTreasure.Name = "btnAddTreasure";
            this.btnAddTreasure.Size = new System.Drawing.Size(82, 27);
            this.btnAddTreasure.TabIndex = 20;
            this.btnAddTreasure.Text = "Add";
            this.btnAddTreasure.UseVisualStyleBackColor = true;
            this.btnAddTreasure.Click += new System.EventHandler(this.btnAddTreasure_Click);
            // 
            // GenerateLootButton
            // 
            this.GenerateLootButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenerateLootButton.Location = new System.Drawing.Point(188, 3);
            this.GenerateLootButton.Name = "GenerateLootButton";
            this.GenerateLootButton.Size = new System.Drawing.Size(102, 27);
            this.GenerateLootButton.TabIndex = 19;
            this.GenerateLootButton.Text = "Get Lewtz!!!";
            this.GenerateLootButton.UseVisualStyleBackColor = true;
            this.GenerateLootButton.Click += new System.EventHandler(this.GenerateLootButton_Click);
            // 
            // btnRemoveTreasure
            // 
            this.btnRemoveTreasure.Enabled = false;
            this.btnRemoveTreasure.Location = new System.Drawing.Point(91, 3);
            this.btnRemoveTreasure.Name = "btnRemoveTreasure";
            this.btnRemoveTreasure.Size = new System.Drawing.Size(91, 27);
            this.btnRemoveTreasure.TabIndex = 35;
            this.btnRemoveTreasure.Text = "Remove";
            this.btnRemoveTreasure.UseVisualStyleBackColor = true;
            this.btnRemoveTreasure.Click += new System.EventHandler(this.btnRemoveTreasure_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.AutoScrollMinSize = new System.Drawing.Size(547, 51);
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flowLayoutPanel1.Controls.Add(this.grpPanel1);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(583, 417);
            this.flowLayoutPanel1.TabIndex = 12;
            // 
            // grpPanel1
            // 
            this.grpPanel1.AutoSize = true;
            this.grpPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grpPanel1.Controls.Add(this.pnlInput9);
            this.grpPanel1.Controls.Add(this.pnlInput8);
            this.grpPanel1.Controls.Add(this.pnlInput7);
            this.grpPanel1.Controls.Add(this.pnlInput0);
            this.grpPanel1.Controls.Add(this.pnlInput1);
            this.grpPanel1.Controls.Add(this.pnlInput5);
            this.grpPanel1.Controls.Add(this.pnlInput6);
            this.grpPanel1.Controls.Add(this.pnlInput4);
            this.grpPanel1.Controls.Add(this.pnlInput2);
            this.grpPanel1.Controls.Add(this.pnlInput3);
            this.grpPanel1.Location = new System.Drawing.Point(3, 3);
            this.grpPanel1.Name = "grpPanel1";
            this.grpPanel1.Size = new System.Drawing.Size(569, 374);
            this.grpPanel1.TabIndex = 0;
            // 
            // pnlInput9
            // 
            this.pnlInput9.AutoSize = true;
            this.pnlInput9.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlInput9.Controls.Add(this.CoinsBox10);
            this.pnlInput9.Controls.Add(this.checkBox10);
            this.pnlInput9.Controls.Add(this.ItemsBox10);
            this.pnlInput9.Controls.Add(this.NumberToRollBox10);
            this.pnlInput9.Controls.Add(this.GoodsBox10);
            this.pnlInput9.Controls.Add(this.label10);
            this.pnlInput9.Controls.Add(this.LevelBox10);
            this.pnlInput9.Location = new System.Drawing.Point(3, 341);
            this.pnlInput9.Name = "pnlInput9";
            this.pnlInput9.Size = new System.Drawing.Size(562, 30);
            this.pnlInput9.TabIndex = 39;
            this.pnlInput9.Visible = false;
            // 
            // CoinsBox10
            // 
            this.CoinsBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoinsBox10.FormattingEnabled = true;
            this.CoinsBox10.Items.AddRange(new object[] {
            "None",
            "1/10",
            "Half",
            "Standard",
            "Double",
            "Triple"});
            this.CoinsBox10.Location = new System.Drawing.Point(199, 3);
            this.CoinsBox10.Name = "CoinsBox10";
            this.CoinsBox10.Size = new System.Drawing.Size(116, 24);
            this.CoinsBox10.TabIndex = 21;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(0, 3);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(18, 17);
            this.checkBox10.TabIndex = 26;
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // ItemsBox10
            // 
            this.ItemsBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemsBox10.FormattingEnabled = true;
            this.ItemsBox10.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.ItemsBox10.Location = new System.Drawing.Point(443, 3);
            this.ItemsBox10.Name = "ItemsBox10";
            this.ItemsBox10.Size = new System.Drawing.Size(116, 24);
            this.ItemsBox10.TabIndex = 23;
            // 
            // NumberToRollBox10
            // 
            this.NumberToRollBox10.Location = new System.Drawing.Point(24, 3);
            this.NumberToRollBox10.Name = "NumberToRollBox10";
            this.NumberToRollBox10.Size = new System.Drawing.Size(55, 22);
            this.NumberToRollBox10.TabIndex = 25;
            // 
            // GoodsBox10
            // 
            this.GoodsBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GoodsBox10.FormattingEnabled = true;
            this.GoodsBox10.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.GoodsBox10.Location = new System.Drawing.Point(321, 3);
            this.GoodsBox10.Name = "GoodsBox10";
            this.GoodsBox10.Size = new System.Drawing.Size(116, 24);
            this.GoodsBox10.TabIndex = 22;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.label10.Location = new System.Drawing.Point(85, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 17);
            this.label10.TabIndex = 27;
            this.label10.Text = "x   Level";
            // 
            // LevelBox10
            // 
            this.LevelBox10.FormattingEnabled = true;
            this.LevelBox10.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.LevelBox10.Location = new System.Drawing.Point(151, 3);
            this.LevelBox10.Name = "LevelBox10";
            this.LevelBox10.Size = new System.Drawing.Size(42, 24);
            this.LevelBox10.TabIndex = 24;
            // 
            // pnlInput8
            // 
            this.pnlInput8.AutoSize = true;
            this.pnlInput8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlInput8.Controls.Add(this.CoinsBox9);
            this.pnlInput8.Controls.Add(this.checkBox9);
            this.pnlInput8.Controls.Add(this.ItemsBox9);
            this.pnlInput8.Controls.Add(this.NumberToRollBox9);
            this.pnlInput8.Controls.Add(this.GoodsBox9);
            this.pnlInput8.Controls.Add(this.label9);
            this.pnlInput8.Controls.Add(this.LevelBox9);
            this.pnlInput8.Location = new System.Drawing.Point(4, 308);
            this.pnlInput8.Name = "pnlInput8";
            this.pnlInput8.Size = new System.Drawing.Size(562, 30);
            this.pnlInput8.TabIndex = 38;
            this.pnlInput8.Visible = false;
            // 
            // CoinsBox9
            // 
            this.CoinsBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoinsBox9.FormattingEnabled = true;
            this.CoinsBox9.Items.AddRange(new object[] {
            "None",
            "1/10",
            "Half",
            "Standard",
            "Double",
            "Triple"});
            this.CoinsBox9.Location = new System.Drawing.Point(199, 3);
            this.CoinsBox9.Name = "CoinsBox9";
            this.CoinsBox9.Size = new System.Drawing.Size(116, 24);
            this.CoinsBox9.TabIndex = 21;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(0, 3);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(18, 17);
            this.checkBox9.TabIndex = 26;
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // ItemsBox9
            // 
            this.ItemsBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemsBox9.FormattingEnabled = true;
            this.ItemsBox9.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.ItemsBox9.Location = new System.Drawing.Point(443, 3);
            this.ItemsBox9.Name = "ItemsBox9";
            this.ItemsBox9.Size = new System.Drawing.Size(116, 24);
            this.ItemsBox9.TabIndex = 23;
            // 
            // NumberToRollBox9
            // 
            this.NumberToRollBox9.Location = new System.Drawing.Point(24, 3);
            this.NumberToRollBox9.Name = "NumberToRollBox9";
            this.NumberToRollBox9.Size = new System.Drawing.Size(55, 22);
            this.NumberToRollBox9.TabIndex = 25;
            // 
            // GoodsBox9
            // 
            this.GoodsBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GoodsBox9.FormattingEnabled = true;
            this.GoodsBox9.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.GoodsBox9.Location = new System.Drawing.Point(321, 3);
            this.GoodsBox9.Name = "GoodsBox9";
            this.GoodsBox9.Size = new System.Drawing.Size(116, 24);
            this.GoodsBox9.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.label9.Location = new System.Drawing.Point(85, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 17);
            this.label9.TabIndex = 27;
            this.label9.Text = "x   Level";
            // 
            // LevelBox9
            // 
            this.LevelBox9.FormattingEnabled = true;
            this.LevelBox9.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.LevelBox9.Location = new System.Drawing.Point(151, 3);
            this.LevelBox9.Name = "LevelBox9";
            this.LevelBox9.Size = new System.Drawing.Size(42, 24);
            this.LevelBox9.TabIndex = 24;
            // 
            // pnlInput7
            // 
            this.pnlInput7.AutoSize = true;
            this.pnlInput7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlInput7.Controls.Add(this.CoinsBox8);
            this.pnlInput7.Controls.Add(this.checkBox8);
            this.pnlInput7.Controls.Add(this.ItemsBox8);
            this.pnlInput7.Controls.Add(this.NumberToRollBox8);
            this.pnlInput7.Controls.Add(this.GoodsBox8);
            this.pnlInput7.Controls.Add(this.label8);
            this.pnlInput7.Controls.Add(this.LevelBox8);
            this.pnlInput7.Location = new System.Drawing.Point(4, 275);
            this.pnlInput7.Name = "pnlInput7";
            this.pnlInput7.Size = new System.Drawing.Size(562, 30);
            this.pnlInput7.TabIndex = 37;
            this.pnlInput7.Visible = false;
            // 
            // CoinsBox8
            // 
            this.CoinsBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoinsBox8.FormattingEnabled = true;
            this.CoinsBox8.Items.AddRange(new object[] {
            "None",
            "1/10",
            "Half",
            "Standard",
            "Double",
            "Triple"});
            this.CoinsBox8.Location = new System.Drawing.Point(199, 3);
            this.CoinsBox8.Name = "CoinsBox8";
            this.CoinsBox8.Size = new System.Drawing.Size(116, 24);
            this.CoinsBox8.TabIndex = 21;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(0, 7);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(18, 17);
            this.checkBox8.TabIndex = 26;
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // ItemsBox8
            // 
            this.ItemsBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemsBox8.FormattingEnabled = true;
            this.ItemsBox8.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.ItemsBox8.Location = new System.Drawing.Point(443, 3);
            this.ItemsBox8.Name = "ItemsBox8";
            this.ItemsBox8.Size = new System.Drawing.Size(116, 24);
            this.ItemsBox8.TabIndex = 23;
            // 
            // NumberToRollBox8
            // 
            this.NumberToRollBox8.Location = new System.Drawing.Point(24, 3);
            this.NumberToRollBox8.Name = "NumberToRollBox8";
            this.NumberToRollBox8.Size = new System.Drawing.Size(55, 22);
            this.NumberToRollBox8.TabIndex = 25;
            // 
            // GoodsBox8
            // 
            this.GoodsBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GoodsBox8.FormattingEnabled = true;
            this.GoodsBox8.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.GoodsBox8.Location = new System.Drawing.Point(321, 3);
            this.GoodsBox8.Name = "GoodsBox8";
            this.GoodsBox8.Size = new System.Drawing.Size(116, 24);
            this.GoodsBox8.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.label8.Location = new System.Drawing.Point(85, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 17);
            this.label8.TabIndex = 27;
            this.label8.Text = "x   Level";
            // 
            // LevelBox8
            // 
            this.LevelBox8.FormattingEnabled = true;
            this.LevelBox8.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.LevelBox8.Location = new System.Drawing.Point(151, 3);
            this.LevelBox8.Name = "LevelBox8";
            this.LevelBox8.Size = new System.Drawing.Size(42, 24);
            this.LevelBox8.TabIndex = 24;
            // 
            // pnlInput0
            // 
            this.pnlInput0.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlInput0.Controls.Add(this.lblItems);
            this.pnlInput0.Controls.Add(this.GoodsLabel);
            this.pnlInput0.Controls.Add(this.lblCoins);
            this.pnlInput0.Controls.Add(this.CheckBox1);
            this.pnlInput0.Controls.Add(this.label1);
            this.pnlInput0.Controls.Add(this.NumberToRollBox1);
            this.pnlInput0.Controls.Add(this.ItemsBox1);
            this.pnlInput0.Controls.Add(this.GoodsBox1);
            this.pnlInput0.Controls.Add(this.LevelBox1);
            this.pnlInput0.Controls.Add(this.CoinsBox1);
            this.pnlInput0.Location = new System.Drawing.Point(4, 3);
            this.pnlInput0.Name = "pnlInput0";
            this.pnlInput0.Size = new System.Drawing.Size(562, 50);
            this.pnlInput0.TabIndex = 36;
            // 
            // lblItems
            // 
            this.lblItems.AutoSize = true;
            this.lblItems.Location = new System.Drawing.Point(486, 1);
            this.lblItems.Name = "lblItems";
            this.lblItems.Size = new System.Drawing.Size(41, 17);
            this.lblItems.TabIndex = 11;
            this.lblItems.Text = "Items";
            // 
            // GoodsLabel
            // 
            this.GoodsLabel.AutoSize = true;
            this.GoodsLabel.Location = new System.Drawing.Point(347, 1);
            this.GoodsLabel.Name = "GoodsLabel";
            this.GoodsLabel.Size = new System.Drawing.Size(50, 17);
            this.GoodsLabel.TabIndex = 8;
            this.GoodsLabel.Text = "Goods";
            // 
            // lblCoins
            // 
            this.lblCoins.AutoSize = true;
            this.lblCoins.Location = new System.Drawing.Point(234, 1);
            this.lblCoins.Name = "lblCoins";
            this.lblCoins.Size = new System.Drawing.Size(43, 17);
            this.lblCoins.TabIndex = 6;
            this.lblCoins.Text = "Coins";
            // 
            // CheckBox1
            // 
            this.CheckBox1.AutoSize = true;
            this.CheckBox1.Location = new System.Drawing.Point(0, 24);
            this.CheckBox1.Name = "CheckBox1";
            this.CheckBox1.Size = new System.Drawing.Size(18, 17);
            this.CheckBox1.TabIndex = 4;
            this.CheckBox1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.label1.Location = new System.Drawing.Point(85, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "x   Level";
            // 
            // NumberToRollBox1
            // 
            this.NumberToRollBox1.Location = new System.Drawing.Point(24, 20);
            this.NumberToRollBox1.Name = "NumberToRollBox1";
            this.NumberToRollBox1.Size = new System.Drawing.Size(55, 22);
            this.NumberToRollBox1.TabIndex = 18;
            // 
            // ItemsBox1
            // 
            this.ItemsBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemsBox1.FormattingEnabled = true;
            this.ItemsBox1.Items.AddRange(new object[] {
            "None",
            "Half",
            "Standard",
            "Double",
            "Triple"});
            this.ItemsBox1.Location = new System.Drawing.Point(443, 20);
            this.ItemsBox1.Name = "ItemsBox1";
            this.ItemsBox1.Size = new System.Drawing.Size(116, 24);
            this.ItemsBox1.TabIndex = 16;
            // 
            // GoodsBox1
            // 
            this.GoodsBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GoodsBox1.FormattingEnabled = true;
            this.GoodsBox1.Items.AddRange(new object[] {
            "None",
            "Half",
            "Standard",
            "Double",
            "Triple"});
            this.GoodsBox1.Location = new System.Drawing.Point(321, 20);
            this.GoodsBox1.Name = "GoodsBox1";
            this.GoodsBox1.Size = new System.Drawing.Size(116, 24);
            this.GoodsBox1.TabIndex = 15;
            // 
            // LevelBox1
            // 
            this.LevelBox1.FormattingEnabled = true;
            this.LevelBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.LevelBox1.Location = new System.Drawing.Point(151, 20);
            this.LevelBox1.Name = "LevelBox1";
            this.LevelBox1.Size = new System.Drawing.Size(42, 24);
            this.LevelBox1.TabIndex = 17;
            this.LevelBox1.Text = "1";
            // 
            // CoinsBox1
            // 
            this.CoinsBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoinsBox1.FormattingEnabled = true;
            this.CoinsBox1.Items.AddRange(new object[] {
            "None",
            "1/10",
            "Half",
            "Standard",
            "Double",
            "Triple"});
            this.CoinsBox1.Location = new System.Drawing.Point(199, 20);
            this.CoinsBox1.Name = "CoinsBox1";
            this.CoinsBox1.Size = new System.Drawing.Size(116, 24);
            this.CoinsBox1.TabIndex = 14;
            // 
            // pnlInput1
            // 
            this.pnlInput1.AutoSize = true;
            this.pnlInput1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlInput1.Controls.Add(this.CoinsBox2);
            this.pnlInput1.Controls.Add(this.CheckBox2);
            this.pnlInput1.Controls.Add(this.ItemsBox2);
            this.pnlInput1.Controls.Add(this.NumberToRollBox2);
            this.pnlInput1.Controls.Add(this.GoodsBox2);
            this.pnlInput1.Controls.Add(this.label2);
            this.pnlInput1.Controls.Add(this.LevelBox2);
            this.pnlInput1.Location = new System.Drawing.Point(4, 59);
            this.pnlInput1.Name = "pnlInput1";
            this.pnlInput1.Size = new System.Drawing.Size(562, 30);
            this.pnlInput1.TabIndex = 29;
            this.pnlInput1.Visible = false;
            // 
            // CoinsBox2
            // 
            this.CoinsBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoinsBox2.FormattingEnabled = true;
            this.CoinsBox2.Items.AddRange(new object[] {
            "None",
            "1/10",
            "Half",
            "Standard",
            "Double",
            "Triple"});
            this.CoinsBox2.Location = new System.Drawing.Point(199, 3);
            this.CoinsBox2.Name = "CoinsBox2";
            this.CoinsBox2.Size = new System.Drawing.Size(116, 24);
            this.CoinsBox2.TabIndex = 21;
            // 
            // CheckBox2
            // 
            this.CheckBox2.AutoSize = true;
            this.CheckBox2.Location = new System.Drawing.Point(0, 7);
            this.CheckBox2.Name = "CheckBox2";
            this.CheckBox2.Size = new System.Drawing.Size(18, 17);
            this.CheckBox2.TabIndex = 26;
            this.CheckBox2.UseVisualStyleBackColor = true;
            // 
            // ItemsBox2
            // 
            this.ItemsBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemsBox2.FormattingEnabled = true;
            this.ItemsBox2.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.ItemsBox2.Location = new System.Drawing.Point(443, 3);
            this.ItemsBox2.Name = "ItemsBox2";
            this.ItemsBox2.Size = new System.Drawing.Size(116, 24);
            this.ItemsBox2.TabIndex = 23;
            // 
            // NumberToRollBox2
            // 
            this.NumberToRollBox2.Location = new System.Drawing.Point(24, 3);
            this.NumberToRollBox2.Name = "NumberToRollBox2";
            this.NumberToRollBox2.Size = new System.Drawing.Size(55, 22);
            this.NumberToRollBox2.TabIndex = 25;
            // 
            // GoodsBox2
            // 
            this.GoodsBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GoodsBox2.FormattingEnabled = true;
            this.GoodsBox2.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.GoodsBox2.Location = new System.Drawing.Point(321, 3);
            this.GoodsBox2.Name = "GoodsBox2";
            this.GoodsBox2.Size = new System.Drawing.Size(116, 24);
            this.GoodsBox2.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.label2.Location = new System.Drawing.Point(85, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 17);
            this.label2.TabIndex = 27;
            this.label2.Text = "x   Level";
            // 
            // LevelBox2
            // 
            this.LevelBox2.FormattingEnabled = true;
            this.LevelBox2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.LevelBox2.Location = new System.Drawing.Point(151, 3);
            this.LevelBox2.Name = "LevelBox2";
            this.LevelBox2.Size = new System.Drawing.Size(42, 24);
            this.LevelBox2.TabIndex = 24;
            // 
            // pnlInput5
            // 
            this.pnlInput5.AutoSize = true;
            this.pnlInput5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlInput5.Controls.Add(this.CoinsBox6);
            this.pnlInput5.Controls.Add(this.checkBox6);
            this.pnlInput5.Controls.Add(this.ItemsBox6);
            this.pnlInput5.Controls.Add(this.NumberToRollBox6);
            this.pnlInput5.Controls.Add(this.GoodsBox6);
            this.pnlInput5.Controls.Add(this.label6);
            this.pnlInput5.Controls.Add(this.LevelBox6);
            this.pnlInput5.Location = new System.Drawing.Point(4, 203);
            this.pnlInput5.Name = "pnlInput5";
            this.pnlInput5.Size = new System.Drawing.Size(562, 30);
            this.pnlInput5.TabIndex = 33;
            this.pnlInput5.Visible = false;
            // 
            // CoinsBox6
            // 
            this.CoinsBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoinsBox6.FormattingEnabled = true;
            this.CoinsBox6.Items.AddRange(new object[] {
            "None",
            "1/10",
            "Half",
            "Standard",
            "Double",
            "Triple"});
            this.CoinsBox6.Location = new System.Drawing.Point(199, 3);
            this.CoinsBox6.Name = "CoinsBox6";
            this.CoinsBox6.Size = new System.Drawing.Size(116, 24);
            this.CoinsBox6.TabIndex = 21;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(3, 7);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(18, 17);
            this.checkBox6.TabIndex = 26;
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // ItemsBox6
            // 
            this.ItemsBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemsBox6.FormattingEnabled = true;
            this.ItemsBox6.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.ItemsBox6.Location = new System.Drawing.Point(443, 3);
            this.ItemsBox6.Name = "ItemsBox6";
            this.ItemsBox6.Size = new System.Drawing.Size(116, 24);
            this.ItemsBox6.TabIndex = 23;
            // 
            // NumberToRollBox6
            // 
            this.NumberToRollBox6.Location = new System.Drawing.Point(24, 3);
            this.NumberToRollBox6.Name = "NumberToRollBox6";
            this.NumberToRollBox6.Size = new System.Drawing.Size(55, 22);
            this.NumberToRollBox6.TabIndex = 25;
            // 
            // GoodsBox6
            // 
            this.GoodsBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GoodsBox6.FormattingEnabled = true;
            this.GoodsBox6.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.GoodsBox6.Location = new System.Drawing.Point(321, 3);
            this.GoodsBox6.Name = "GoodsBox6";
            this.GoodsBox6.Size = new System.Drawing.Size(116, 24);
            this.GoodsBox6.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.label6.Location = new System.Drawing.Point(85, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 17);
            this.label6.TabIndex = 27;
            this.label6.Text = "x   Level";
            // 
            // LevelBox6
            // 
            this.LevelBox6.FormattingEnabled = true;
            this.LevelBox6.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.LevelBox6.Location = new System.Drawing.Point(151, 3);
            this.LevelBox6.Name = "LevelBox6";
            this.LevelBox6.Size = new System.Drawing.Size(42, 24);
            this.LevelBox6.TabIndex = 24;
            // 
            // pnlInput6
            // 
            this.pnlInput6.AutoSize = true;
            this.pnlInput6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlInput6.Controls.Add(this.CoinsBox7);
            this.pnlInput6.Controls.Add(this.checkBox7);
            this.pnlInput6.Controls.Add(this.ItemsBox7);
            this.pnlInput6.Controls.Add(this.NumberToRollBox7);
            this.pnlInput6.Controls.Add(this.GoodsBox7);
            this.pnlInput6.Controls.Add(this.label7);
            this.pnlInput6.Controls.Add(this.LevelBox7);
            this.pnlInput6.Location = new System.Drawing.Point(4, 239);
            this.pnlInput6.Name = "pnlInput6";
            this.pnlInput6.Size = new System.Drawing.Size(562, 30);
            this.pnlInput6.TabIndex = 34;
            this.pnlInput6.Visible = false;
            // 
            // CoinsBox7
            // 
            this.CoinsBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoinsBox7.FormattingEnabled = true;
            this.CoinsBox7.Items.AddRange(new object[] {
            "None",
            "1/10",
            "Half",
            "Standard",
            "Double",
            "Triple"});
            this.CoinsBox7.Location = new System.Drawing.Point(199, 3);
            this.CoinsBox7.Name = "CoinsBox7";
            this.CoinsBox7.Size = new System.Drawing.Size(116, 24);
            this.CoinsBox7.TabIndex = 21;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(3, 7);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(18, 17);
            this.checkBox7.TabIndex = 26;
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // ItemsBox7
            // 
            this.ItemsBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemsBox7.FormattingEnabled = true;
            this.ItemsBox7.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.ItemsBox7.Location = new System.Drawing.Point(443, 3);
            this.ItemsBox7.Name = "ItemsBox7";
            this.ItemsBox7.Size = new System.Drawing.Size(116, 24);
            this.ItemsBox7.TabIndex = 23;
            // 
            // NumberToRollBox7
            // 
            this.NumberToRollBox7.Location = new System.Drawing.Point(24, 3);
            this.NumberToRollBox7.Name = "NumberToRollBox7";
            this.NumberToRollBox7.Size = new System.Drawing.Size(55, 22);
            this.NumberToRollBox7.TabIndex = 25;
            // 
            // GoodsBox7
            // 
            this.GoodsBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GoodsBox7.FormattingEnabled = true;
            this.GoodsBox7.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.GoodsBox7.Location = new System.Drawing.Point(321, 3);
            this.GoodsBox7.Name = "GoodsBox7";
            this.GoodsBox7.Size = new System.Drawing.Size(116, 24);
            this.GoodsBox7.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.label7.Location = new System.Drawing.Point(85, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 17);
            this.label7.TabIndex = 27;
            this.label7.Text = "x   Level";
            // 
            // LevelBox7
            // 
            this.LevelBox7.FormattingEnabled = true;
            this.LevelBox7.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.LevelBox7.Location = new System.Drawing.Point(151, 3);
            this.LevelBox7.Name = "LevelBox7";
            this.LevelBox7.Size = new System.Drawing.Size(42, 24);
            this.LevelBox7.TabIndex = 24;
            // 
            // pnlInput4
            // 
            this.pnlInput4.AutoSize = true;
            this.pnlInput4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlInput4.Controls.Add(this.CoinsBox5);
            this.pnlInput4.Controls.Add(this.checkBox5);
            this.pnlInput4.Controls.Add(this.ItemsBox5);
            this.pnlInput4.Controls.Add(this.NumberToRollBox5);
            this.pnlInput4.Controls.Add(this.GoodsBox5);
            this.pnlInput4.Controls.Add(this.label5);
            this.pnlInput4.Controls.Add(this.LevelBox5);
            this.pnlInput4.Location = new System.Drawing.Point(4, 167);
            this.pnlInput4.Name = "pnlInput4";
            this.pnlInput4.Size = new System.Drawing.Size(562, 30);
            this.pnlInput4.TabIndex = 32;
            this.pnlInput4.Visible = false;
            // 
            // CoinsBox5
            // 
            this.CoinsBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoinsBox5.FormattingEnabled = true;
            this.CoinsBox5.Items.AddRange(new object[] {
            "None",
            "1/10",
            "Half",
            "Standard",
            "Double",
            "Triple"});
            this.CoinsBox5.Location = new System.Drawing.Point(199, 3);
            this.CoinsBox5.Name = "CoinsBox5";
            this.CoinsBox5.Size = new System.Drawing.Size(116, 24);
            this.CoinsBox5.TabIndex = 21;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(0, 7);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(18, 17);
            this.checkBox5.TabIndex = 26;
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // ItemsBox5
            // 
            this.ItemsBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemsBox5.FormattingEnabled = true;
            this.ItemsBox5.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.ItemsBox5.Location = new System.Drawing.Point(443, 3);
            this.ItemsBox5.Name = "ItemsBox5";
            this.ItemsBox5.Size = new System.Drawing.Size(116, 24);
            this.ItemsBox5.TabIndex = 23;
            // 
            // NumberToRollBox5
            // 
            this.NumberToRollBox5.Location = new System.Drawing.Point(24, 3);
            this.NumberToRollBox5.Name = "NumberToRollBox5";
            this.NumberToRollBox5.Size = new System.Drawing.Size(55, 22);
            this.NumberToRollBox5.TabIndex = 25;
            // 
            // GoodsBox5
            // 
            this.GoodsBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GoodsBox5.FormattingEnabled = true;
            this.GoodsBox5.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.GoodsBox5.Location = new System.Drawing.Point(321, 3);
            this.GoodsBox5.Name = "GoodsBox5";
            this.GoodsBox5.Size = new System.Drawing.Size(116, 24);
            this.GoodsBox5.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.label5.Location = new System.Drawing.Point(85, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 17);
            this.label5.TabIndex = 27;
            this.label5.Text = "x   Level";
            // 
            // LevelBox5
            // 
            this.LevelBox5.FormattingEnabled = true;
            this.LevelBox5.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.LevelBox5.Location = new System.Drawing.Point(151, 3);
            this.LevelBox5.Name = "LevelBox5";
            this.LevelBox5.Size = new System.Drawing.Size(42, 24);
            this.LevelBox5.TabIndex = 24;
            // 
            // pnlInput2
            // 
            this.pnlInput2.AutoSize = true;
            this.pnlInput2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlInput2.Controls.Add(this.CoinsBox3);
            this.pnlInput2.Controls.Add(this.checkBox3);
            this.pnlInput2.Controls.Add(this.ItemsBox3);
            this.pnlInput2.Controls.Add(this.NumberToRollBox3);
            this.pnlInput2.Controls.Add(this.GoodsBox3);
            this.pnlInput2.Controls.Add(this.label3);
            this.pnlInput2.Controls.Add(this.LevelBox3);
            this.pnlInput2.Location = new System.Drawing.Point(4, 95);
            this.pnlInput2.Name = "pnlInput2";
            this.pnlInput2.Size = new System.Drawing.Size(562, 30);
            this.pnlInput2.TabIndex = 30;
            this.pnlInput2.Visible = false;
            // 
            // CoinsBox3
            // 
            this.CoinsBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoinsBox3.FormattingEnabled = true;
            this.CoinsBox3.Items.AddRange(new object[] {
            "None",
            "1/10",
            "Half",
            "Standard",
            "Double",
            "Triple"});
            this.CoinsBox3.Location = new System.Drawing.Point(199, 3);
            this.CoinsBox3.Name = "CoinsBox3";
            this.CoinsBox3.Size = new System.Drawing.Size(116, 24);
            this.CoinsBox3.TabIndex = 21;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(0, 7);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(18, 17);
            this.checkBox3.TabIndex = 26;
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // ItemsBox3
            // 
            this.ItemsBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemsBox3.FormattingEnabled = true;
            this.ItemsBox3.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.ItemsBox3.Location = new System.Drawing.Point(443, 3);
            this.ItemsBox3.Name = "ItemsBox3";
            this.ItemsBox3.Size = new System.Drawing.Size(116, 24);
            this.ItemsBox3.TabIndex = 23;
            // 
            // NumberToRollBox3
            // 
            this.NumberToRollBox3.Location = new System.Drawing.Point(24, 3);
            this.NumberToRollBox3.Name = "NumberToRollBox3";
            this.NumberToRollBox3.Size = new System.Drawing.Size(55, 22);
            this.NumberToRollBox3.TabIndex = 25;
            // 
            // GoodsBox3
            // 
            this.GoodsBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GoodsBox3.FormattingEnabled = true;
            this.GoodsBox3.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.GoodsBox3.Location = new System.Drawing.Point(321, 3);
            this.GoodsBox3.Name = "GoodsBox3";
            this.GoodsBox3.Size = new System.Drawing.Size(116, 24);
            this.GoodsBox3.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.label3.Location = new System.Drawing.Point(85, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 17);
            this.label3.TabIndex = 27;
            this.label3.Text = "x   Level";
            // 
            // LevelBox3
            // 
            this.LevelBox3.FormattingEnabled = true;
            this.LevelBox3.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.LevelBox3.Location = new System.Drawing.Point(151, 3);
            this.LevelBox3.Name = "LevelBox3";
            this.LevelBox3.Size = new System.Drawing.Size(42, 24);
            this.LevelBox3.TabIndex = 24;
            // 
            // pnlInput3
            // 
            this.pnlInput3.AutoSize = true;
            this.pnlInput3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlInput3.Controls.Add(this.CoinsBox4);
            this.pnlInput3.Controls.Add(this.checkBox4);
            this.pnlInput3.Controls.Add(this.ItemsBox4);
            this.pnlInput3.Controls.Add(this.NumberToRollBox4);
            this.pnlInput3.Controls.Add(this.GoodsBox4);
            this.pnlInput3.Controls.Add(this.label4);
            this.pnlInput3.Controls.Add(this.LevelBox4);
            this.pnlInput3.Location = new System.Drawing.Point(4, 131);
            this.pnlInput3.Name = "pnlInput3";
            this.pnlInput3.Size = new System.Drawing.Size(562, 30);
            this.pnlInput3.TabIndex = 31;
            this.pnlInput3.Visible = false;
            // 
            // CoinsBox4
            // 
            this.CoinsBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoinsBox4.FormattingEnabled = true;
            this.CoinsBox4.Items.AddRange(new object[] {
            "None",
            "1/10",
            "Half",
            "Standard",
            "Double",
            "Triple"});
            this.CoinsBox4.Location = new System.Drawing.Point(199, 3);
            this.CoinsBox4.Name = "CoinsBox4";
            this.CoinsBox4.Size = new System.Drawing.Size(116, 24);
            this.CoinsBox4.TabIndex = 21;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(0, 7);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(18, 17);
            this.checkBox4.TabIndex = 26;
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // ItemsBox4
            // 
            this.ItemsBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemsBox4.FormattingEnabled = true;
            this.ItemsBox4.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.ItemsBox4.Location = new System.Drawing.Point(443, 3);
            this.ItemsBox4.Name = "ItemsBox4";
            this.ItemsBox4.Size = new System.Drawing.Size(116, 24);
            this.ItemsBox4.TabIndex = 23;
            // 
            // NumberToRollBox4
            // 
            this.NumberToRollBox4.Location = new System.Drawing.Point(24, 3);
            this.NumberToRollBox4.Name = "NumberToRollBox4";
            this.NumberToRollBox4.Size = new System.Drawing.Size(55, 22);
            this.NumberToRollBox4.TabIndex = 25;
            // 
            // GoodsBox4
            // 
            this.GoodsBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GoodsBox4.FormattingEnabled = true;
            this.GoodsBox4.Items.AddRange(new object[] {
            "None",
            "1/2",
            "Standard",
            "Double",
            "Triple"});
            this.GoodsBox4.Location = new System.Drawing.Point(321, 3);
            this.GoodsBox4.Name = "GoodsBox4";
            this.GoodsBox4.Size = new System.Drawing.Size(116, 24);
            this.GoodsBox4.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.label4.Location = new System.Drawing.Point(85, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 17);
            this.label4.TabIndex = 27;
            this.label4.Text = "x   Level";
            // 
            // LevelBox4
            // 
            this.LevelBox4.FormattingEnabled = true;
            this.LevelBox4.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.LevelBox4.Location = new System.Drawing.Point(151, 3);
            this.LevelBox4.Name = "LevelBox4";
            this.LevelBox4.Size = new System.Drawing.Size(42, 24);
            this.LevelBox4.TabIndex = 24;
            // 
            // grpRank
            // 
            this.grpRank.Controls.Add(this.chkIncludeAllRank);
            this.grpRank.Controls.Add(this.chkIncludeMajor);
            this.grpRank.Controls.Add(this.chkIncludeMedium);
            this.grpRank.Controls.Add(this.chkIncludeMinor);
            this.grpRank.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpRank.Location = new System.Drawing.Point(479, 12);
            this.grpRank.Name = "grpRank";
            this.grpRank.Size = new System.Drawing.Size(95, 156);
            this.grpRank.TabIndex = 15;
            this.grpRank.TabStop = false;
            this.grpRank.Text = "Rank";
            // 
            // chkIncludeAllRank
            // 
            this.chkIncludeAllRank.AutoSize = true;
            this.chkIncludeAllRank.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeAllRank.Location = new System.Drawing.Point(6, 102);
            this.chkIncludeAllRank.Name = "chkIncludeAllRank";
            this.chkIncludeAllRank.Size = new System.Drawing.Size(45, 21);
            this.chkIncludeAllRank.TabIndex = 24;
            this.chkIncludeAllRank.Text = "All";
            this.chkIncludeAllRank.UseVisualStyleBackColor = true;
            // 
            // chkIncludeMajor
            // 
            this.chkIncludeMajor.AutoSize = true;
            this.chkIncludeMajor.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeMajor.Location = new System.Drawing.Point(6, 75);
            this.chkIncludeMajor.Name = "chkIncludeMajor";
            this.chkIncludeMajor.Size = new System.Drawing.Size(65, 21);
            this.chkIncludeMajor.TabIndex = 23;
            this.chkIncludeMajor.Text = "Major";
            this.chkIncludeMajor.UseVisualStyleBackColor = true;
            // 
            // chkIncludeMedium
            // 
            this.chkIncludeMedium.AutoSize = true;
            this.chkIncludeMedium.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeMedium.Location = new System.Drawing.Point(6, 48);
            this.chkIncludeMedium.Name = "chkIncludeMedium";
            this.chkIncludeMedium.Size = new System.Drawing.Size(79, 21);
            this.chkIncludeMedium.TabIndex = 22;
            this.chkIncludeMedium.Text = "Medium";
            this.chkIncludeMedium.UseVisualStyleBackColor = true;
            // 
            // chkIncludeMinor
            // 
            this.chkIncludeMinor.AutoSize = true;
            this.chkIncludeMinor.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeMinor.Location = new System.Drawing.Point(6, 21);
            this.chkIncludeMinor.Name = "chkIncludeMinor";
            this.chkIncludeMinor.Size = new System.Drawing.Size(65, 21);
            this.chkIncludeMinor.TabIndex = 21;
            this.chkIncludeMinor.Text = "Minor";
            this.chkIncludeMinor.UseVisualStyleBackColor = true;
            // 
            // grpSalvage
            // 
            this.grpSalvage.Location = new System.Drawing.Point(3, 167);
            this.grpSalvage.Name = "grpSalvage";
            this.grpSalvage.Size = new System.Drawing.Size(214, 116);
            this.grpSalvage.TabIndex = 16;
            this.grpSalvage.TabStop = false;
            this.grpSalvage.Text = "Salvage";
            // 
            // grpSpecificArea
            // 
            this.grpSpecificArea.Controls.Add(this.checkBox11);
            this.grpSpecificArea.Controls.Add(this.chkIncludeDesert);
            this.grpSpecificArea.Controls.Add(this.chkIbcludeFrostburn);
            this.grpSpecificArea.Location = new System.Drawing.Point(223, 168);
            this.grpSpecificArea.Name = "grpSpecificArea";
            this.grpSpecificArea.Size = new System.Drawing.Size(353, 115);
            this.grpSpecificArea.TabIndex = 17;
            this.grpSpecificArea.TabStop = false;
            this.grpSpecificArea.Text = "Specific Areas";
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(7, 78);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(73, 21);
            this.checkBox11.TabIndex = 2;
            this.checkBox11.Text = "Things";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // chkIncludeDesert
            // 
            this.chkIncludeDesert.AutoSize = true;
            this.chkIncludeDesert.Location = new System.Drawing.Point(7, 50);
            this.chkIncludeDesert.Name = "chkIncludeDesert";
            this.chkIncludeDesert.Size = new System.Drawing.Size(105, 21);
            this.chkIncludeDesert.TabIndex = 1;
            this.chkIncludeDesert.Text = "Desert Stuff";
            this.chkIncludeDesert.UseVisualStyleBackColor = true;
            // 
            // chkIbcludeFrostburn
            // 
            this.chkIbcludeFrostburn.AutoSize = true;
            this.chkIbcludeFrostburn.Location = new System.Drawing.Point(7, 22);
            this.chkIbcludeFrostburn.Name = "chkIbcludeFrostburn";
            this.chkIbcludeFrostburn.Size = new System.Drawing.Size(91, 21);
            this.chkIbcludeFrostburn.TabIndex = 0;
            this.chkIbcludeFrostburn.Text = "Frostburn";
            this.chkIbcludeFrostburn.UseVisualStyleBackColor = true;
            // 
            // grpIncludeItems
            // 
            this.grpIncludeItems.Controls.Add(this.chkIncludeTools);
            this.grpIncludeItems.Controls.Add(this.chkIncludeAlchemy);
            this.grpIncludeItems.Controls.Add(this.chkIncludeSalvage);
            this.grpIncludeItems.Controls.Add(this.chkIncludeAlcohol);
            this.grpIncludeItems.Controls.Add(this.chkIncludeAll);
            this.grpIncludeItems.Controls.Add(this.chkIncludeArt);
            this.grpIncludeItems.Controls.Add(this.chkIncludeGems);
            this.grpIncludeItems.Controls.Add(this.chkIncludeArmor);
            this.grpIncludeItems.Controls.Add(this.chkIncludeWeapons);
            this.grpIncludeItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpIncludeItems.Location = new System.Drawing.Point(3, 11);
            this.grpIncludeItems.Name = "grpIncludeItems";
            this.grpIncludeItems.Size = new System.Drawing.Size(214, 157);
            this.grpIncludeItems.TabIndex = 13;
            this.grpIncludeItems.TabStop = false;
            this.grpIncludeItems.Text = "Items";
            // 
            // chkIncludeTools
            // 
            this.chkIncludeTools.AutoSize = true;
            this.chkIncludeTools.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeTools.Location = new System.Drawing.Point(113, 75);
            this.chkIncludeTools.Name = "chkIncludeTools";
            this.chkIncludeTools.Size = new System.Drawing.Size(65, 21);
            this.chkIncludeTools.TabIndex = 9;
            this.chkIncludeTools.Text = "Tools";
            this.chkIncludeTools.UseVisualStyleBackColor = true;
            // 
            // chkIncludeAlchemy
            // 
            this.chkIncludeAlchemy.AutoSize = true;
            this.chkIncludeAlchemy.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeAlchemy.Location = new System.Drawing.Point(113, 21);
            this.chkIncludeAlchemy.Name = "chkIncludeAlchemy";
            this.chkIncludeAlchemy.Size = new System.Drawing.Size(83, 21);
            this.chkIncludeAlchemy.TabIndex = 8;
            this.chkIncludeAlchemy.Text = "Alchemy";
            this.chkIncludeAlchemy.UseVisualStyleBackColor = true;
            // 
            // chkIncludeSalvage
            // 
            this.chkIncludeSalvage.AutoSize = true;
            this.chkIncludeSalvage.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeSalvage.Location = new System.Drawing.Point(113, 100);
            this.chkIncludeSalvage.Name = "chkIncludeSalvage";
            this.chkIncludeSalvage.Size = new System.Drawing.Size(81, 21);
            this.chkIncludeSalvage.TabIndex = 7;
            this.chkIncludeSalvage.Text = "Salvage";
            this.chkIncludeSalvage.UseVisualStyleBackColor = true;
            // 
            // chkIncludeAlcohol
            // 
            this.chkIncludeAlcohol.AutoSize = true;
            this.chkIncludeAlcohol.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeAlcohol.Location = new System.Drawing.Point(113, 48);
            this.chkIncludeAlcohol.Name = "chkIncludeAlcohol";
            this.chkIncludeAlcohol.Size = new System.Drawing.Size(76, 21);
            this.chkIncludeAlcohol.TabIndex = 6;
            this.chkIncludeAlcohol.Text = "Alcohol";
            this.chkIncludeAlcohol.UseVisualStyleBackColor = true;
            // 
            // chkIncludeAll
            // 
            this.chkIncludeAll.AutoSize = true;
            this.chkIncludeAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeAll.Location = new System.Drawing.Point(77, 129);
            this.chkIncludeAll.Name = "chkIncludeAll";
            this.chkIncludeAll.Size = new System.Drawing.Size(45, 21);
            this.chkIncludeAll.TabIndex = 5;
            this.chkIncludeAll.Text = "All";
            this.chkIncludeAll.UseVisualStyleBackColor = true;
            // 
            // chkIncludeArt
            // 
            this.chkIncludeArt.AutoSize = true;
            this.chkIncludeArt.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeArt.Location = new System.Drawing.Point(3, 102);
            this.chkIncludeArt.Name = "chkIncludeArt";
            this.chkIncludeArt.Size = new System.Drawing.Size(100, 21);
            this.chkIncludeArt.TabIndex = 4;
            this.chkIncludeArt.Text = "Art Objects";
            this.chkIncludeArt.UseVisualStyleBackColor = true;
            // 
            // chkIncludeGems
            // 
            this.chkIncludeGems.AutoSize = true;
            this.chkIncludeGems.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeGems.Location = new System.Drawing.Point(3, 75);
            this.chkIncludeGems.Name = "chkIncludeGems";
            this.chkIncludeGems.Size = new System.Drawing.Size(67, 21);
            this.chkIncludeGems.TabIndex = 3;
            this.chkIncludeGems.Text = "Gems";
            this.chkIncludeGems.UseVisualStyleBackColor = true;
            // 
            // chkIncludeArmor
            // 
            this.chkIncludeArmor.AutoSize = true;
            this.chkIncludeArmor.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeArmor.Location = new System.Drawing.Point(3, 48);
            this.chkIncludeArmor.Name = "chkIncludeArmor";
            this.chkIncludeArmor.Size = new System.Drawing.Size(68, 21);
            this.chkIncludeArmor.TabIndex = 1;
            this.chkIncludeArmor.Text = "Armor";
            this.chkIncludeArmor.UseVisualStyleBackColor = true;
            // 
            // chkIncludeWeapons
            // 
            this.chkIncludeWeapons.AutoSize = true;
            this.chkIncludeWeapons.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeWeapons.Location = new System.Drawing.Point(3, 21);
            this.chkIncludeWeapons.Name = "chkIncludeWeapons";
            this.chkIncludeWeapons.Size = new System.Drawing.Size(90, 21);
            this.chkIncludeWeapons.TabIndex = 0;
            this.chkIncludeWeapons.Text = "Weapons";
            this.chkIncludeWeapons.UseVisualStyleBackColor = true;
            // 
            // grpIncludeMagic
            // 
            this.grpIncludeMagic.Controls.Add(this.chkIncludeAllMagic);
            this.grpIncludeMagic.Controls.Add(this.chkIncludeWondrous);
            this.grpIncludeMagic.Controls.Add(this.chkIncludeRods);
            this.grpIncludeMagic.Controls.Add(this.chkIncludePotions);
            this.grpIncludeMagic.Controls.Add(this.chkIncludeStaves);
            this.grpIncludeMagic.Controls.Add(this.chkIncludeMagic);
            this.grpIncludeMagic.Controls.Add(this.chkIncludeWands);
            this.grpIncludeMagic.Controls.Add(this.chkIncludeRings);
            this.grpIncludeMagic.Controls.Add(this.chkIncludeScrolls);
            this.grpIncludeMagic.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpIncludeMagic.Location = new System.Drawing.Point(223, 11);
            this.grpIncludeMagic.Name = "grpIncludeMagic";
            this.grpIncludeMagic.Size = new System.Drawing.Size(250, 157);
            this.grpIncludeMagic.TabIndex = 14;
            this.grpIncludeMagic.TabStop = false;
            this.grpIncludeMagic.Text = "Magic";
            // 
            // chkIncludeAllMagic
            // 
            this.chkIncludeAllMagic.AutoSize = true;
            this.chkIncludeAllMagic.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeAllMagic.Location = new System.Drawing.Point(82, 129);
            this.chkIncludeAllMagic.Name = "chkIncludeAllMagic";
            this.chkIncludeAllMagic.Size = new System.Drawing.Size(45, 21);
            this.chkIncludeAllMagic.TabIndex = 20;
            this.chkIncludeAllMagic.Text = "All";
            this.chkIncludeAllMagic.UseVisualStyleBackColor = true;
            // 
            // chkIncludeWondrous
            // 
            this.chkIncludeWondrous.AutoSize = true;
            this.chkIncludeWondrous.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeWondrous.Location = new System.Drawing.Point(120, 102);
            this.chkIncludeWondrous.Name = "chkIncludeWondrous";
            this.chkIncludeWondrous.Size = new System.Drawing.Size(118, 19);
            this.chkIncludeWondrous.TabIndex = 19;
            this.chkIncludeWondrous.Text = "Wondrous Items";
            this.chkIncludeWondrous.UseVisualStyleBackColor = true;
            // 
            // chkIncludeRods
            // 
            this.chkIncludeRods.AutoSize = true;
            this.chkIncludeRods.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeRods.Location = new System.Drawing.Point(120, 48);
            this.chkIncludeRods.Name = "chkIncludeRods";
            this.chkIncludeRods.Size = new System.Drawing.Size(63, 21);
            this.chkIncludeRods.TabIndex = 18;
            this.chkIncludeRods.Text = "Rods";
            this.chkIncludeRods.UseVisualStyleBackColor = true;
            // 
            // chkIncludePotions
            // 
            this.chkIncludePotions.AutoSize = true;
            this.chkIncludePotions.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludePotions.Location = new System.Drawing.Point(120, 75);
            this.chkIncludePotions.Name = "chkIncludePotions";
            this.chkIncludePotions.Size = new System.Drawing.Size(77, 21);
            this.chkIncludePotions.TabIndex = 17;
            this.chkIncludePotions.Text = "Potions";
            this.chkIncludePotions.UseVisualStyleBackColor = true;
            // 
            // chkIncludeStaves
            // 
            this.chkIncludeStaves.AutoSize = true;
            this.chkIncludeStaves.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeStaves.Location = new System.Drawing.Point(120, 21);
            this.chkIncludeStaves.Name = "chkIncludeStaves";
            this.chkIncludeStaves.Size = new System.Drawing.Size(73, 21);
            this.chkIncludeStaves.TabIndex = 16;
            this.chkIncludeStaves.Text = "Staves";
            this.chkIncludeStaves.UseVisualStyleBackColor = true;
            // 
            // chkIncludeMagic
            // 
            this.chkIncludeMagic.AutoSize = true;
            this.chkIncludeMagic.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeMagic.Location = new System.Drawing.Point(6, 21);
            this.chkIncludeMagic.Name = "chkIncludeMagic";
            this.chkIncludeMagic.Size = new System.Drawing.Size(104, 21);
            this.chkIncludeMagic.TabIndex = 15;
            this.chkIncludeMagic.Text = "Magic Items";
            this.chkIncludeMagic.UseVisualStyleBackColor = true;
            // 
            // chkIncludeWands
            // 
            this.chkIncludeWands.AutoSize = true;
            this.chkIncludeWands.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeWands.Location = new System.Drawing.Point(6, 102);
            this.chkIncludeWands.Name = "chkIncludeWands";
            this.chkIncludeWands.Size = new System.Drawing.Size(74, 21);
            this.chkIncludeWands.TabIndex = 6;
            this.chkIncludeWands.Text = "Wands";
            this.chkIncludeWands.UseVisualStyleBackColor = true;
            // 
            // chkIncludeRings
            // 
            this.chkIncludeRings.AutoSize = true;
            this.chkIncludeRings.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeRings.Location = new System.Drawing.Point(6, 48);
            this.chkIncludeRings.Name = "chkIncludeRings";
            this.chkIncludeRings.Size = new System.Drawing.Size(66, 21);
            this.chkIncludeRings.TabIndex = 5;
            this.chkIncludeRings.Text = "Rings";
            this.chkIncludeRings.UseVisualStyleBackColor = true;
            // 
            // chkIncludeScrolls
            // 
            this.chkIncludeScrolls.AutoSize = true;
            this.chkIncludeScrolls.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludeScrolls.Location = new System.Drawing.Point(6, 75);
            this.chkIncludeScrolls.Name = "chkIncludeScrolls";
            this.chkIncludeScrolls.Size = new System.Drawing.Size(72, 21);
            this.chkIncludeScrolls.TabIndex = 2;
            this.chkIncludeScrolls.Text = "Scrolls";
            this.chkIncludeScrolls.UseVisualStyleBackColor = true;
            // 
            // splitText
            // 
            this.splitText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitText.Location = new System.Drawing.Point(0, 0);
            this.splitText.Name = "splitText";
            this.splitText.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitText.Panel1
            // 
            this.splitText.Panel1.Controls.Add(this.textBox1);
            // 
            // splitText.Panel2
            // 
            this.splitText.Panel2.Controls.Add(this.textBox2);
            this.splitText.Size = new System.Drawing.Size(601, 714);
            this.splitText.SplitterDistance = 521;
            this.splitText.TabIndex = 15;
            // 
            // textBox1
            // 
            this.textBox1.AcceptsReturn = true;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(601, 521);
            this.textBox1.TabIndex = 13;
            this.textBox1.WordWrap = false;
            // 
            // textBox2
            // 
            this.textBox2.AcceptsReturn = true;
            this.textBox2.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox2.Location = new System.Drawing.Point(0, 0);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox2.Size = new System.Drawing.Size(601, 189);
            this.textBox2.TabIndex = 14;
            this.textBox2.WordWrap = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1192, 28);
            this.menuStrip1.TabIndex = 30;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.loadToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(195, 24);
            this.saveToolStripMenuItem.Text = "Save";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lootTableToolStripMenuItem});
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(195, 24);
            this.loadToolStripMenuItem.Text = "Load";
            // 
            // lootTableToolStripMenuItem
            // 
            this.lootTableToolStripMenuItem.Name = "lootTableToolStripMenuItem";
            this.lootTableToolStripMenuItem.Size = new System.Drawing.Size(155, 24);
            this.lootTableToolStripMenuItem.Text = "Loot Tables";
            this.lootTableToolStripMenuItem.Click += new System.EventHandler(this.lootTableToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.Q)));
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(195, 24);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.ToolTipText = "Exits the application";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click_1);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Lewtz Tables|*.Lewt";
            // 
            // FormLewtz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1192, 744);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormLewtz";
            this.Text = "Lewtz!";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.grpPanel1.ResumeLayout(false);
            this.grpPanel1.PerformLayout();
            this.pnlInput9.ResumeLayout(false);
            this.pnlInput9.PerformLayout();
            this.pnlInput8.ResumeLayout(false);
            this.pnlInput8.PerformLayout();
            this.pnlInput7.ResumeLayout(false);
            this.pnlInput7.PerformLayout();
            this.pnlInput0.ResumeLayout(false);
            this.pnlInput0.PerformLayout();
            this.pnlInput1.ResumeLayout(false);
            this.pnlInput1.PerformLayout();
            this.pnlInput5.ResumeLayout(false);
            this.pnlInput5.PerformLayout();
            this.pnlInput6.ResumeLayout(false);
            this.pnlInput6.PerformLayout();
            this.pnlInput4.ResumeLayout(false);
            this.pnlInput4.PerformLayout();
            this.pnlInput2.ResumeLayout(false);
            this.pnlInput2.PerformLayout();
            this.pnlInput3.ResumeLayout(false);
            this.pnlInput3.PerformLayout();
            this.grpRank.ResumeLayout(false);
            this.grpRank.PerformLayout();
            this.grpSpecificArea.ResumeLayout(false);
            this.grpSpecificArea.PerformLayout();
            this.grpIncludeItems.ResumeLayout(false);
            this.grpIncludeItems.PerformLayout();
            this.grpIncludeMagic.ResumeLayout(false);
            this.grpIncludeMagic.PerformLayout();
            this.splitText.Panel1.ResumeLayout(false);
            this.splitText.Panel1.PerformLayout();
            this.splitText.Panel2.ResumeLayout(false);
            this.splitText.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitText)).EndInit();
            this.splitText.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnAddTreasure;
        private System.Windows.Forms.Button btnRemoveTreasure;
        private System.Windows.Forms.Button GenerateLootButton;
        private System.Windows.Forms.GroupBox grpIncludeItems;
        private System.Windows.Forms.CheckBox chkIncludeSalvage;
        private System.Windows.Forms.CheckBox chkIncludeAlcohol;
        private System.Windows.Forms.CheckBox chkIncludeAll;
        private System.Windows.Forms.CheckBox chkIncludeArt;
        private System.Windows.Forms.CheckBox chkIncludeGems;
        private System.Windows.Forms.CheckBox chkIncludeArmor;
        private System.Windows.Forms.CheckBox chkIncludeWeapons;
        private System.Windows.Forms.GroupBox grpIncludeMagic;
        private System.Windows.Forms.CheckBox chkIncludeAllMagic;
        private System.Windows.Forms.CheckBox chkIncludeWondrous;
        private System.Windows.Forms.CheckBox chkIncludeRods;
        private System.Windows.Forms.CheckBox chkIncludePotions;
        private System.Windows.Forms.CheckBox chkIncludeStaves;
        private System.Windows.Forms.CheckBox chkIncludeMagic;
        private System.Windows.Forms.CheckBox chkIncludeWands;
        private System.Windows.Forms.CheckBox chkIncludeRings;
        private System.Windows.Forms.CheckBox chkIncludeScrolls;
        private System.Windows.Forms.GroupBox grpRank;
        private System.Windows.Forms.CheckBox chkIncludeAllRank;
        private System.Windows.Forms.CheckBox chkIncludeMajor;
        private System.Windows.Forms.CheckBox chkIncludeMedium;
        private System.Windows.Forms.CheckBox chkIncludeMinor;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lootTableToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel grpPanel1;
        private System.Windows.Forms.Panel pnlInput9;
        private System.Windows.Forms.ComboBox CoinsBox10;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.ComboBox ItemsBox10;
        private System.Windows.Forms.TextBox NumberToRollBox10;
        private System.Windows.Forms.ComboBox GoodsBox10;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox LevelBox10;
        private System.Windows.Forms.Panel pnlInput8;
        private System.Windows.Forms.ComboBox CoinsBox9;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.ComboBox ItemsBox9;
        private System.Windows.Forms.TextBox NumberToRollBox9;
        private System.Windows.Forms.ComboBox GoodsBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox LevelBox9;
        private System.Windows.Forms.Panel pnlInput7;
        private System.Windows.Forms.ComboBox CoinsBox8;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.ComboBox ItemsBox8;
        private System.Windows.Forms.TextBox NumberToRollBox8;
        private System.Windows.Forms.ComboBox GoodsBox8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox LevelBox8;
        private System.Windows.Forms.Panel pnlInput0;
        private System.Windows.Forms.Label lblItems;
        private System.Windows.Forms.Label GoodsLabel;
        private System.Windows.Forms.Label lblCoins;
        private System.Windows.Forms.CheckBox CheckBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NumberToRollBox1;
        private System.Windows.Forms.ComboBox ItemsBox1;
        private System.Windows.Forms.ComboBox GoodsBox1;
        private System.Windows.Forms.ComboBox LevelBox1;
        private System.Windows.Forms.ComboBox CoinsBox1;
        private System.Windows.Forms.Panel pnlInput1;
        private System.Windows.Forms.ComboBox CoinsBox2;
        private System.Windows.Forms.CheckBox CheckBox2;
        private System.Windows.Forms.ComboBox ItemsBox2;
        private System.Windows.Forms.TextBox NumberToRollBox2;
        private System.Windows.Forms.ComboBox GoodsBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox LevelBox2;
        private System.Windows.Forms.Panel pnlInput5;
        private System.Windows.Forms.ComboBox CoinsBox6;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.ComboBox ItemsBox6;
        private System.Windows.Forms.TextBox NumberToRollBox6;
        private System.Windows.Forms.ComboBox GoodsBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox LevelBox6;
        private System.Windows.Forms.Panel pnlInput6;
        private System.Windows.Forms.ComboBox CoinsBox7;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.ComboBox ItemsBox7;
        private System.Windows.Forms.TextBox NumberToRollBox7;
        private System.Windows.Forms.ComboBox GoodsBox7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox LevelBox7;
        private System.Windows.Forms.Panel pnlInput4;
        private System.Windows.Forms.ComboBox CoinsBox5;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.ComboBox ItemsBox5;
        private System.Windows.Forms.TextBox NumberToRollBox5;
        private System.Windows.Forms.ComboBox GoodsBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox LevelBox5;
        private System.Windows.Forms.Panel pnlInput2;
        private System.Windows.Forms.ComboBox CoinsBox3;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.ComboBox ItemsBox3;
        private System.Windows.Forms.TextBox NumberToRollBox3;
        private System.Windows.Forms.ComboBox GoodsBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox LevelBox3;
        private System.Windows.Forms.Panel pnlInput3;
        private System.Windows.Forms.ComboBox CoinsBox4;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.ComboBox ItemsBox4;
        private System.Windows.Forms.TextBox NumberToRollBox4;
        private System.Windows.Forms.ComboBox GoodsBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox LevelBox4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.CheckBox chkIncludeAlchemy;
        private System.Windows.Forms.CheckBox chkIncludeTools;
        private System.Windows.Forms.GroupBox grpSalvage;
        private System.Windows.Forms.GroupBox grpSpecificArea;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox chkIncludeDesert;
        private System.Windows.Forms.CheckBox chkIbcludeFrostburn;
        private System.Windows.Forms.SplitContainer splitText;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.CheckBox chkCombineHoards;
    }
}

